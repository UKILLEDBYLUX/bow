package net.pvp.bowoptimizer;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

public class BowOptimizerClient implements ClientModInitializer {

    public static final String MOD_ID = "bowoptimizer";
    private static boolean enabled = true;
    private static KeyBinding toggleKey;

    // 3 тика — минимальное ванильное натяжение тетивы для полета стрелы (getPullProgress >= 0.1)
    private static final int MIN_PULL_TICKS = 3;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.bowoptimizer.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_B,
                "category.bowoptimizer"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null || client.interactionManager == null) {
            return;
        }

        while (toggleKey.wasPressed()) {
            enabled = !enabled;
            client.player.sendMessage(
                    Text.literal("§7[§6BowOptimizer§7] " + (enabled ? "§aВключен" : "§cВыключен")),
                    true
            );
        }

        if (!enabled) {
            return;
        }

        if (!client.options.useKey.isPressed()) {
            return;
        }

        Hand bowHand = null;
        if (client.player.getMainHandStack().getItem() instanceof BowItem) {
            bowHand = Hand.MAIN_HAND;
        } else if (client.player.getOffHandStack().getItem() instanceof BowItem) {
            bowHand = Hand.OFF_HAND;
        }

        if (bowHand == null) {
            return;
        }

        ItemStack bowStack = client.player.getStackInHand(bowHand);

        if (!client.player.isInCreativeMode() && client.player.getProjectileType(bowStack).isEmpty()) {
            return;
        }

        if (client.player.isUsingItem() && client.player.getActiveHand() == bowHand) {
            int useTime = client.player.getItemUseTime();

            if (useTime >= MIN_PULL_TICKS) {
                client.interactionManager.stopUsingItem(client.player);
            }
        } else if (!client.player.isUsingItem()) {
            client.interactionManager.interactItem(client.player, bowHand);
        }
    }
}
